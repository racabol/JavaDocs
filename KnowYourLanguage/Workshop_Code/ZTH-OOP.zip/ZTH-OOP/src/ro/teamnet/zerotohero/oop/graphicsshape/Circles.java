package ro.teamnet.zerotohero.oop.graphicsshape;

/**
 * Created by andre on 4/21/2015.
 */
public class Circles {

    public double getAreaPub(){
        Circle c = new Circle();
        return c.area();
    }

    public void getAreaDef(){
        Circle c = new Circle();
        c.fillColor();
        c.fillColor(4);
        c.fillColor(3f);
    }
}
