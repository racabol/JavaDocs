package ro.teamnet.zerotohero;

import ro.teamnet.zerotohero.oop.graphicsshape.Circle;

/**
 * Created by andre on 4/21/2015.
 */
public class Canvas {
    void getArea() {
        Circle circle = new Circle();
        System.out.println("The area of canvas is" + circle.area());
    }
}
